/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Wed Sep 25 2019                                           */
/*    Description:  Clawbot Template (Individual Motors)                      */
/*                                                                            */
/*    Name:                                                                   */
/*    Date:                                                                   */
/*    Class:                                                                  */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// LeftMotor5           motor         5               
// RightMotor6          motor         6               
// Claw10               motor         10              
// Arm1                 motor         8               
// Controller1          controller                    
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
    while (true) {

      //Arm Motor
      if((Controller1.Axis2.value() == 0)) {
        
        Arm1.stop();

      }
      
      while ((Controller1.Axis2.value() >= 10)) {

        Arm1.spin(directionType::fwd, Controller1.Axis2.value()/2, velocityUnits::pct);
      
      }

      while ((Controller1.Axis2.value() <= -10)) { 

        Arm1.spin(directionType::rev, Controller1.Axis2.value()/2 * -1, velocityUnits::pct);
      
      }
      
      //Left Motor
      if(((Controller1.Axis3.value() + Controller1.Axis4.value())/2 == 0)) {

        LeftMotor5.stop();
   
      }       
      
      while (((Controller1.Axis3.value() + Controller1.Axis4.value())/2 >= 10)) {
      
       LeftMotor5.spin(directionType::fwd, (Controller1.Axis3.value() + Controller1.Axis4.value())/2, velocityUnits::pct); //(Axis3+Axis4)/2;
        
      }
      
      while (((Controller1.Axis3.value() + Controller1.Axis4.value())/2 <= -10)) {
      
       LeftMotor5.spin(directionType::rev, (Controller1.Axis3.value() + Controller1.Axis4.value())/2 * -1, velocityUnits::pct); //(Axis3+Axis4)/2;
        
      }
      
      //Right Motor
      if(((Controller1.Axis4.value() - Controller1.Axis3.value())/2 == 0)) {

        RightMotor6.stop();
   
      }       
      
      while (((Controller1.Axis4.value() - Controller1.Axis3.value())/2 >= 10)) {
      
       RightMotor6.spin(directionType::fwd, (Controller1.Axis4.value() - Controller1.Axis4.value())/2, velocityUnits::pct); //(Axis3-Axis4)/2;
        
      }
      
      while (((Controller1.Axis3.value() - Controller1.Axis4.value())/2 <= -10)) {
      
       RightMotor6.spin(directionType::rev, (Controller1.Axis3.value() + Controller1.Axis4.value())/2 * -1, velocityUnits::pct); //(Axis3-Axis4)/2;
        
      }

      task::sleep(20);
    } 
}
