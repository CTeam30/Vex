/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       Shane Collins (Team 1)                                    */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// LeftMotor5           motor         5               
// RightMotor6          motor         6               
// Claw15               motor         15              
// Arm1                 motor         1               
// Arm2                 motor         2               
// ArmExtender11        motor         11              
// RangeFinderG_H       sonar         G, H            
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

// A global instance of competition
competition Competition;

// define your global instances of motors and other devices here


int Speed;
int Dist = 200;
int autonrun = 0;
int spindist = 0;

void MoveSens () {

  LeftMotor5.setStopping(coast);
  RightMotor6.setStopping(coast);

   while (true) {
    if (RangeFinderG_H.distance(mm) < 0 & autonrun > 1) {
      Brain.Screen.print("<0");
     }
     else {
       autonrun = 2;

       Brain.Screen.clearLine();
       Brain.Screen.print("Detected ");
       Brain.Screen.print(RangeFinderG_H.distance(mm));

       LeftMotor5.setVelocity((RangeFinderG_H.distance(mm) - Dist), percent);
       RightMotor6.setVelocity((RangeFinderG_H.distance(mm) - Dist), percent);

       spindist = RangeFinderG_H.distance(mm) - Dist;

       if (spindist > 200) {
         spindist = 200;
       }
       
       LeftMotor5.spinFor(spindist, degrees, false);
       RightMotor6.spinFor(spindist * -1, degrees, true);

     //  task::sleep(100);

      // LeftMotor5.stop();
     //  RightMotor6.stop();

      // if (RangeFinderG_H.distance(mm) - Dist < 0 ) {
        // Brain.Screen.print("Breaking");
        // break;
       //}
      // LeftMotor5.spinFor((RangeFinderG_H.distance(mm) - Dist) * 2, degrees, false);
      // RightMotor6.spinFor((RangeFinderG_H.distance(mm) - Dist) * 2 * -1, degrees, true);
     }
    
   // task::sleep(2000);

     if (RangeFinderG_H.distance(mm) - Dist < 0 & autonrun > 1) {
       Brain.Screen.print("Breaking");
        LeftMotor5.setStopping(hold);
        RightMotor6.setStopping(hold);
       break;
     }
     
   }

}







/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  

  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
  
  Arm1.setStopping(hold);
  Arm2.setStopping(hold);
  ArmExtender11.setStopping(hold);
  Claw15.setStopping(hold);
  LeftMotor5.setStopping(hold);
  RightMotor6.setStopping(hold);
  
  Arm1.setMaxTorque(100, percent);
  Arm2.setMaxTorque(100, percent);
  ArmExtender11.setMaxTorque(100,percent);
  Claw15.setMaxTorque(100, percent);
  LeftMotor5.setMaxTorque(100, percent);
  RightMotor6.setMaxTorque(100, percent);
  
  Arm1.setVelocity(100, percent);
  Arm2.setVelocity(100, percent);
  ArmExtender11.setVelocity(100,percent);
  Claw15.setVelocity(100, percent);
  LeftMotor5.setVelocity(100, percent);
  RightMotor6.setVelocity(100, percent);
 

}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void autonomous(void) {
  // ..........................................................................
  // Insert autonomous user code here.
  // ..........................................................................
  
  //Autonomous

  Claw15.setTimeout(1, seconds);

  LeftMotor5.spinFor(-50, degrees, false);
  RightMotor6.spinFor(50, degrees);

  task::sleep(100);

  MoveSens(); //Move Robot forwrd to first cube
  
  Controller1.Screen.print("Closing Claw");
  Claw15.spinToPosition(-300, degrees); //Grab cube with claw

  Controller1.Screen.print("Lifting Arm");
  Arm1.spinFor(200, degrees, false);
  Arm2.spinFor(200, degrees); //Lift Arm

  LeftMotor5.spinFor(900, degrees); //Turn Robot Right to face next cube

  MoveSens(); //Move Robot to second cube.

  LeftMotor5.spinFor(900, degrees); //Turn Robot right to face the goal zone

  LeftMotor5.spinFor(300, degrees, false);
  RightMotor6.spinFor(300, degrees); //Pushed the cube into the goal zone

  Arm1.spinFor(-150, degrees);
  Arm2.spinFor(-150, degrees); //Bring down Arm

  Claw15.spinToPosition(200, degrees);
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void usercontrol(void) {
  
    while (true) {

      LeftMotor5.spin(directionType::fwd, (Controller1.Axis4.value() + Controller1.Axis3.value())/2, velocityUnits::pct); //(Axis3+Axis4)/2;
      RightMotor6.spin(directionType::fwd, (Controller1.Axis4.value() - Controller1.Axis3.value())/2, velocityUnits::pct);//(Axis3-Axis4)/2;
      
      //Arm Motor
      if((Controller1.Axis2.value() == 0)) {
        
        Arm1.stop();
        Arm2.stop();

      }
      
      while ((Controller1.Axis2.value() >= 10)) {

        Arm1.spin(directionType::fwd, Controller1.Axis2.value()/2, velocityUnits::pct);
        Arm2.spin(directionType::fwd, Controller1.Axis2.value()/2, velocityUnits::pct);
      
      }

      while ((Controller1.Axis2.value() <= -10)) { 

        Arm1.spin(directionType::rev, Controller1.Axis2.value()/2 * -1, velocityUnits::pct);
        Arm2.spin(directionType::rev, Controller1.Axis2.value()/2 * -1, velocityUnits::pct);
      
      }
      

      //Arm Extender
      if((Controller1.Axis1.value() == 0)) {
        
        ArmExtender11.stop();

      }
      
      while ((Controller1.Axis1.value() >= 10)) {

        ArmExtender11.spin(directionType::fwd, Controller1.Axis1.value()/2, velocityUnits::pct);
      
      }

      while ((Controller1.Axis1.value() <= -10)) { 

        ArmExtender11.spin(directionType::rev, Controller1.Axis1.value()/2 * -1, velocityUnits::pct);
      
      }
     task::sleep(20);
    } 
}


//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.

  

  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}
