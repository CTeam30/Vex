/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Wed Sep 25 2019                                           */
/*    Description:  Clawbot Template (Individual Motors)                      */
/*                                                                            */
/*    Name:                                                                   */
/*    Date:                                                                   */
/*    Class:                                                                  */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// LeftMotor5           motor         5               
// RightMotor6          motor         6               
// Claw15               motor         15              
// Arm1                 motor         1               
// Controller1          controller                    
// Arm2                 motor         2               
// ArmExtender11        motor         11              
// RangeFinderG_H       sonar         G, H            
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

int Speed;
int Dist = 25;

void MoveSens () {

   while (true) {
    if (RangeFinderG_H.distance(mm) < 0) {
      LeftMotor5.spin(directionType::fwd); 
      RightMotor6.spin(directionType::fwd);
     }
     else {
       LeftMotor5.spin(directionType::fwd, (RangeFinderG_H.distance(mm) - Dist) * 2, velocityUnits::pct);
      RightMotor6.spin(directionType::fwd, (RangeFinderG_H.distance(mm) - Dist) * 2, velocityUnits::pct);
     }

     if (RangeFinderG_H.distance(mm) - Dist <= 0 ) {
       break;
     }
     
   }

}


int main() {
  
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  while(true) {
    Controller1.Screen.clearLine();
    Controller1.Screen.setCursor(1,1); 
    Controller1.Screen.print(RangeFinderG_H.distance(mm));
    task::sleep(20);
  }

  
  Arm1.setStopping(hold);
  Arm2.setStopping(hold);
  ArmExtender11.setStopping(hold);
  Claw15.setStopping(hold);
  LeftMotor5.setStopping(hold);
  RightMotor6.setStopping(hold);
  
  Arm1.setMaxTorque(100, percent);
  Arm2.setMaxTorque(100, percent);
  ArmExtender11.setMaxTorque(100,percent);
  Claw15.setMaxTorque(100, percent);
  LeftMotor5.setMaxTorque(100, percent);
  RightMotor6.setMaxTorque(100, percent);
  
  Arm1.setVelocity(100, percent);
  Arm2.setVelocity(100, percent);
  ArmExtender11.setVelocity(100,percent);
  Claw15.setVelocity(100, percent);
  LeftMotor5.setVelocity(100, percent);
  RightMotor6.setVelocity(100, percent);
  
 /*
  //Autonomous
  MoveSens(); //Move Robot forwrd to first cube
  
  Claw15.spinToPosition(400, degrees); //Grab cube with claw

  Arm1.spinFor(300, degrees);
  Arm2.spinFor(300, degrees); //Lift Arm

  LeftMotor5.spinFor(900, degrees); //Turn Robot Right to face next cube

  MoveSens(); //Move Robot to second cube.

  LeftMotor5.spinFor(900,degrees); //Turn Robot right to face the goal zone

  LeftMotor5.spinFor(300,degrees);
  LeftMotor5.spinToPosition(300,degrees); //Pushed the cube into the goal zone

  Arm1.spinFor(-150, degrees);
  Arm2.spinFor(-150, degrees); //Bring down Arm

  Claw15.spinToPosition(-200, degrees);

  */


    while (true) {

      LeftMotor5.spin(directionType::fwd, (Controller1.Axis4.value() + Controller1.Axis3.value())/2, velocityUnits::pct); //(Axis3+Axis4)/2;
      RightMotor6.spin(directionType::fwd, (Controller1.Axis4.value() - Controller1.Axis3.value())/2, velocityUnits::pct);//(Axis3-Axis4)/2;
      
      //Arm Motor
      if((Controller1.Axis2.value() == 0)) {
        
        Arm1.stop();
        Arm2.stop();

      }
      
      while ((Controller1.Axis2.value() >= 10)) {

        Arm1.spin(directionType::fwd, Controller1.Axis2.value()/2, velocityUnits::pct);
        Arm2.spin(directionType::fwd, Controller1.Axis2.value()/2, velocityUnits::pct);
      
      }

      while ((Controller1.Axis2.value() <= -10)) { 

        Arm1.spin(directionType::rev, Controller1.Axis2.value()/2 * -1, velocityUnits::pct);
        Arm2.spin(directionType::rev, Controller1.Axis2.value()/2 * -1, velocityUnits::pct);
      
      }
      

      //Arm Extender
      if((Controller1.Axis1.value() == 0)) {
        
        ArmExtender11.stop();

      }
      
      while ((Controller1.Axis1.value() >= 10)) {

        ArmExtender11.spin(directionType::fwd, Controller1.Axis1.value()/2, velocityUnits::pct);
      
      }

      while ((Controller1.Axis1.value() <= -10)) { 

        ArmExtender11.spin(directionType::rev, Controller1.Axis1.value()/2 * -1, velocityUnits::pct);
      
      }
     task::sleep(20);
    } 
}
